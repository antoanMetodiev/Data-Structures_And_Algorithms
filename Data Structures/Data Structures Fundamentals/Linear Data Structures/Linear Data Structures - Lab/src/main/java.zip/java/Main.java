import implementations.ArrayList;

public class Main {
    public static void main(String[] args) {

        ArrayList<String> names = new ArrayList<>();

        names.add("1");
        names.add("2");
        names.add("3");
        names.add("4");


        System.out.println(names.indexOf("4"));


    }
}
